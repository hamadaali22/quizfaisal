<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class ExpectedAnswer extends Model
{
    protected $table = 'expected_answer';
}
