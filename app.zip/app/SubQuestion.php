<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubQuestion extends Model
{
    protected $table = 'subquestions';
}
