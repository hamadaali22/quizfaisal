<div class="row education-cont text-answer1" id="text-answer1" style="background-color: #fff;border-bottom-color: red;padding: 10px;    margin: 24px;"> 
    <div class="col-md-2 col-sm-6 first-choice-hidden">  
        <div class="form-group">
            <label>from</label>
            <input type="text" name="one" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>to</label>
            <input type="text" name="two" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
</div>                                 
                                     
                                  
                                   