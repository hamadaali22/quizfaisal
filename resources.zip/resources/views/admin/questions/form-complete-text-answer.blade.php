
                                     
                                   
<div class="row education-cont text-answer1" id="text-answer1" style="background-color: #fff;border-bottom-color: red;padding: 10px;    margin: 24px;"> 
    <div class="col-md-2 col-sm-6 first-choice-hidden">  
        <div class="form-group">
            <label>One</label>
            <input type="text" name="one[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>two</label>
            <input type="text" name="two[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>three</label>
            <input type="text" name="three[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>four</label>
            <input type="text" name="four[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>five</label>
            <input type="text" name="five[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>six</label>
            <input type="text" name="six[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>Seven</label>
            <input type="text" name="seven[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>eight</label>
            <input type="text" name="eight[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>nine</label>
            <input type="text" name="nine[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>ten</label>
            <input type="text" name="ten[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>Eleven</label>
            <input type="text" name="eleven[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>Twelve</label>
            <input type="text" name="twelve[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>Thirteen</label>
            <input type="text" name="thirteen[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>Fourteen</label>
            <input type="text" name="fourteen[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden">  
        <div class="form-group">
            <label>Fifteen</label>
            <input type="text" name="fifteen[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
     <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>Sixteen</label>
            <input type="text" name="sixteen[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
</div>  