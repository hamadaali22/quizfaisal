<div class="row education-cont text-answer1" id="text-answer1" style="background-color: #fff;border-bottom-color: red;padding: 10px;    margin: 24px;">
    <div class="col-md-4 col-sm-6 first-choice-hidden">
        <div class="form-group">
            <label>One</label>
            <input type="text" name="one[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 second-choice-hidden" >
        <div class="form-group">
            <label>two</label>
            <input type="text" name="two[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 second-choice-hidden" >
        <div class="form-group">
            <label>three</label>
            <input type="text" name="three[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 second-choice-hidden" >
        <div class="form-group">
            <label>four</label>
            <input type="text" name="four[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 second-choice-hidden" >
        <div class="form-group">
            <label>five</label>
            <input type="text" name="five[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 second-choice-hidden" >
        <div class="form-group">
            <label>six</label>
            <input type="text" name="six[]" class="form-control titleId">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>


</div>
