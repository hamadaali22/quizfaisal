<div class="row education-cont text-answer1" id="text-answer1" style="background-color: #fff;border-bottom-color: red;padding: 10px;    margin: 24px;">
  <div class="col-md-4 col-sm-6 first-choice-hidden">
    <div class="form-group">
      <label>first choice</label>
      <input type="text" name="first_choice" class="form-control titleId">
      <span id="titleError" style="color: red;"></span>
    </div>
  </div>
  <div class="col-md-4 col-sm-6 second-choice-hidden">
    <div class="form-group">
      <label>second choice</label>
      <input type="text" name="second_choice" class="form-control titleId">
      <span id="titleError" style="color: red;"></span>
    </div>
  </div>
  <div class="col-md-4 col-sm-6 third-choice-hidden">
    <div class="form-group">
      <label>third choice</label>
      <input type="text" name="third_choice" class="form-control titleId">
      <span id="titleError" style="color: red;"></span>
    </div>
  </div>
</div>

