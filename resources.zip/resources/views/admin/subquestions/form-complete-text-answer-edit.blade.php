<div class="row education-cont complete-text-answer1" id="text-answer1" style="background-color: #fff;border-bottom-color: red;padding: 10px;    margin: 24px;"> 
    <div class="col-md-2 col-sm-6 first-choice-hidden">  
        <div class="form-group">
            <label>One </label>
            <input type="text" name="one" class="form-control titleId" value="{{$complete_n_one}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>two</label>
            <input type="text" name="two" class="form-control titleId" value="{{$complete_n_two}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>three</label>
            <input type="text" name="three" class="form-control titleId" value="{{$complete_n_three}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>four</label>
            <input type="text" name="four" class="form-control titleId" value="{{$complete_n_four}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>five</label>
            <input type="text" name="five" class="form-control titleId" value="{{$complete_n_three}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>six</label>
            <input type="text" name="six" class="form-control titleId" value="{{$complete_n_six}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>Seven</label>
            <input type="text" name="seven" class="form-control titleId" value="{{$complete_n_seven}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>eight</label>
            <input type="text" name="eight" class="form-control titleId" value="{{$complete_n_eight}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>nine</label>
            <input type="text" name="nine" class="form-control titleId" value="{{$complete_n_nine}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>ten</label>
            <input type="text" name="ten" class="form-control titleId" value="{{$complete_n_ten}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>eleven</label>
            <input type="text" name="eleven" class="form-control titleId" value="{{$complete_n_eleven}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>twelve</label>
            <input type="text" name="twelve" class="form-control titleId" value="{{$complete_n_twelve}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden">  
        <div class="form-group">
            <label>thirteen</label>
            <input type="text" name="thirteen" class="form-control titleId" value="{{$complete_n_thirteen}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden">  
        <div class="form-group">
            <label>fourteen</label>
            <input type="text" name="fourteen" class="form-control titleId" value="{{$complete_n_fourteen}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>fifteen</label>
            <input type="text" name="fifteen" class="form-control titleId" value="{{$complete_n_fifteen}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>
    <div class="col-md-2 col-sm-6 second-choice-hidden" >  
        <div class="form-group">
            <label>sixteen</label>
            <input type="text" name="sixteen" class="form-control titleId" value="{{$complete_n_sixteen}}">
            <span id="titleError" style="color: red;"></span>
        </div>
    </div>

</div>                                 
                                     
                                   