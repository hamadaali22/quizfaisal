<div class="row education-cont true-false1" id="text-answer1" style="background-color: #fff;border-bottom-color: red;padding: 10px;    margin: 24px;">
  <div class="col-md-6 col-sm-6 first-choice-hidden">
       <p></p>

    <div class="form-group">

      <label>The correct answer </label>
      <input type="text" name="first_choice" class="form-control titleId" value="{{$first_choice}}">
      <span id="titleError" style="color: red;"></span>
    </div>
  </div>
  <div class="col-md-6 col-sm-6 second-choice-hidden" >
    <div class="form-group">
      <label>wrong answer</label>
      <input type="text" name="second_choice" class="form-control titleId" value="{{$second_choice}}">
      <span id="titleError" style="color: red;"></span>
    </div>
  </div>
</div>
