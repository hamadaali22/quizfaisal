@extends('layout.front_main')
@section('content')
<global-home></global-home>
@endsection
