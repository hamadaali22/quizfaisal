<footer class="back navbar fixed-bottom">
        <div class="links text-center">
            <a href="#"><i class="fa-brands fa-facebook p-2 mr-2"></i></a>
            <a href="#"><i class="fa-brands fa-instagram p-2 mr-2"></i></a>
            <a href="#"><i class="fa-brands fa-twitter p-2 mr-2"></i></a>
            <a href="#"><i class="fa-brands fa-github p-2 mr-2"></i></a>
        </div>
    </footer>
